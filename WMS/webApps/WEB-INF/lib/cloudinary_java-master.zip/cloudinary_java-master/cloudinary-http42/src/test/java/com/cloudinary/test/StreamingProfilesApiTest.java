package com.cloudinary.test;

/**
 * Created by amir on 25/10/2016.
 */
public class StreamingProfilesApiTest extends AbstractStreamingProfilesApiTest {
}
