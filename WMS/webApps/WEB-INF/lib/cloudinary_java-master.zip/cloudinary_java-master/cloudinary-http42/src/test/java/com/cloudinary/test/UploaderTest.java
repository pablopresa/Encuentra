package com.cloudinary.test;

public class UploaderTest extends AbstractUploaderTest {

}
