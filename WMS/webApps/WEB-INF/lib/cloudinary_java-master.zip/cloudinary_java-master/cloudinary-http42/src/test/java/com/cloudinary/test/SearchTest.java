package com.cloudinary.test;

public class SearchTest extends AbstractSearchTest {
}
