package com.cloudinary.transformation;

/**
 * @deprecated
 */
public abstract class AbstractLayerBuilder extends AbstractLayer {
}
