package com.cloudinary.transformation;

/**
 * @deprecated Use {@link SubtitlesLayer} instead
 */
public class SubtitlesLayerBuilder extends SubtitlesLayer {
}
