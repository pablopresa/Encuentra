package com.cloudinary.transformation;

/**
 * @deprecated Use {@link Layer} instead
 */
public class LayerBuilder extends Layer {
}
