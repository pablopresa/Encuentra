package com.cloudinary.transformation;

public class Layer extends AbstractLayer<Layer> {
    @Override
    Layer getThis() {
        return this;
    }
}