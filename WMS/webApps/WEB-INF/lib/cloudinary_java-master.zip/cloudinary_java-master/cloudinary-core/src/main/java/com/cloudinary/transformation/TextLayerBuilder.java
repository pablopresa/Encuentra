package com.cloudinary.transformation;

/**
 * @deprecated Use {@link TextLayer} instead
 */
public class TextLayerBuilder extends TextLayer {
}
